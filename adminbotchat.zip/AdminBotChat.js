var fetch = global.nodemodule["node-fetch"];

function onLoad(data) {

var onLoadText = "\n\n";
onLoadText += "Đang tải \"AdminBotChat\" by DauPhu\n";
onLoadText += "\n";
onLoadText += "=============================\n";
onLoadText += "+                           +\n";
onLoadText += "+                           +\n";
onLoadText += "+  A D M I N B O T C H A T  +\n";
onLoadText += "+                           +\n";
onLoadText += "+                           +\n";
onLoadText += "=============================\n";
onLoadText += "#############################\n";
onLoadText += "                             \n"
onLoadText += "      Copyright By Tofu      \n";
onLoadText += "                             \n";
onLoadText += "#############################\n";
onLoadText += "\n";
onLoadText += "Đã tải xong plugins và sẵn sàng hoạt động ~~!";

data.log(onLoadText);
data.log(data);

}

var adminbotchat = function adminbotchat(type, data) {
	(async function () {
		var returntext = `꧁chào mừng những người sử dụng bot꧂\n=--+ミ★๖Tɦôηɠ тĭη αɗмĭη bσт ηàү★彡+--=\n𝗔𝗗𝗠𝗜𝗡 𝗡𝗔𝗠𝗘 : Đậu Phụ Nè\n𝑩𝒊𝒆̣̂𝒕 𝒅𝒂𝒏𝒉 : Lùnn\n𝑮𝒊𝒐̛́𝒊 𝒕𝒉𝒊𝒆̣̂𝒖 : Stop!\nI Have Something To You\nI Love You\n𝗧𝗶́𝗻𝗵 𝗰𝗮́𝗰𝗵 : Vui vẻ nhưng đôi lúc hơi khó tính\n𝗖𝗵𝗶𝗲̂̀𝘂 𝗰𝗮𝗼 : 1m58\n𝑺𝒊𝒏𝒉 𝑵𝒈𝒂̀𝒚 : 07-12\n𝑳𝒊𝒆̂𝒏 𝑯𝒆̣̂ :\n𝑰𝒏𝒔𝒕𝒂𝒓𝒈𝒓𝒂𝒎 : dau_phu_2005\n𝗚𝗶𝘁𝗵𝘂𝗯 : DauPhu907\n𝑺𝒐̛̉ 𝑻𝒉𝒊́𝒄𝒉 : Nghe nhạc, nấu ăn\n ngủ nướng\n𝑪𝒂̂𝒏 𝑵𝒂̣̆𝒏𝒈 : 45kg\n𝐈𝐃 𝐅𝐚𝐜𝐞𝐛𝐨𝐨𝐤 : 100022263186510 \n𝗡𝗮𝗺𝗲 𝗜𝗗 : Dau.Phu.Com.Vn\n𝐋𝐢𝐧𝐤 𝐟𝐚𝐜𝐞𝐛𝐨𝐨𝐤 𝐚𝐝𝐦𝐢𝐧 : https://www.facebook.com/Dau.Phu.Com.Vn/\n𝑽𝒂̀𝒊 𝒍𝒐̛̀𝒊 𝒕𝒐̛́𝒊 𝒃𝒂̣𝒏 𝒅𝒖̀𝒏𝒈 : Vui lòng không spam khi sử dụng và trân thành cảm ơn bạn đã sử dụng sản phẩm\n𝙇𝙪̛𝙪 𝙮́ : Đừng có dại dột mà add 2 bot kẻo bị phát hiện là bạn toang đó <3\n𝑪𝒂̉𝒏𝒉 𝒃𝒂́𝒐 : Vui lòng không dùng bot với mục đích xấu hay cố ý report acc facebook\nChúc bạn sử dụng vui vẻ <3\n=--+Đậu Phụ Nè+--=`;
		return {
			handler: "internal",
			data: returntext
		}
	})().then(function (returndata) {
		data.return(returndata);
	});
} 

module.exports = {
	adminbotchat: adminbotchat,
	onLoad
};